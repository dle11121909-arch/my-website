
function showAlert() {
    alert('Chào mừng bạn đến với HR Sandbox!');
}
